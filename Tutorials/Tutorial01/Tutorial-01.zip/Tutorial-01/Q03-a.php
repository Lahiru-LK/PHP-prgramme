<?php
	$a=20;
	$count=0;
	
	while(0<$a){
		$count+=1;
		echo $a." count is ".$count."<br>";
		$a--;
	}
	echo "<br><b>All Counts : </b>".$count;

?>