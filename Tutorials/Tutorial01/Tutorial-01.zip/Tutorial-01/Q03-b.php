<?php
	$a=20;

	
	while(0<=$a){
		if($a%2==0){
			echo "$a - <b>Even</b><br>";
		}
		else{
			echo "$a - <b>Odd</b><br>";
		}
		
		$a--;
	}
	

?>