<?php
	
	$fruit= array("Mango","Orange","Apple","Papaya","Banana");


		if (in_array("Mango"&&"Orange"&&"Apple"&&"Papaya"&&"Banana",$fruit)){
			echo "Values are included in an array";
		}
			else{
				echo "It is not an array”";
			}
	
?>