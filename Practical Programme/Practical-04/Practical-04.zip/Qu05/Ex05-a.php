<!DOCTYPE html>
<html>
	<style>

	
	</style>
	
	<body>

	<?php
	
	$arr=array("Red","Green","Yellow","Blue","White");
    echo "$arr[0]";
	?>

	</body>
</html>