<style>

	
</style>

<body>

<?php

$arr=array("Red","Green","Yellow","Blue","White");

    if (IsSet($arr[3])){
         
        echo $arr[3];
    }
    else{
        echo "No value to show";
         }

?>

</body>
</html>