<!DOCTYPE html>
<html>
	<style>

	
	</style>
	
	<body>

	<?php
	
	$arr=array("Red","Green","Yellow","Blue","White");
    
    echo next($arr)."<br>";
    echo current($arr) ."<br>";
    echo prev($arr) ."<br>";
    echo reset($arr) ."<br>";

	?>

	</body>
</html>