<style>

	
</style>

<body>

<?php

$arr=array("Red","Green","Yellow","Blue","White");

    if (in_array("Blue", $arr)){
         echo "Blue is here";
    }
    else{
        echo "Blue is not available";
         }

?>

</body>
</html>